#ifndef MACROS_H
#define MACROS_H

#define SERVER "127.0.0.1"
#define PORT 9999
#define CMD_LENGTH 10240 //cmd at most 10kb
#define ALIAS_IMG_URL "http://3w6kx9401skz1bup4i1gs9ne.wpengine.netdna-cdn.com/wp-content/uploads/2016/09/telegraph-1.jpg"
#define ALIAS_IMG_NAME "panda1.jpg"

#endif
